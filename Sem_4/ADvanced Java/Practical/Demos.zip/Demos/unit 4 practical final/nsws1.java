public class nsws1 {
        
}
