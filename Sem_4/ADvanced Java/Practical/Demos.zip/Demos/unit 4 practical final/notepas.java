import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class notepas {
    
    
    JTextArea text;
    JMenuItem cut, copy, paste, selectAll;
    
    public notepas() {
        
        
    }
}