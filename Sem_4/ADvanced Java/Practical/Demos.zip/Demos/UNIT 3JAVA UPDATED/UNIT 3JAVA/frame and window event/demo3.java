import javax.swing.*;
import java.awt.event.*;


class demo3 extends JFrame 
{
	demo3()
	{

	setTitle("title2");
	setVisible(true);
	setSize(200,200);
	setLocation(300,400);

	}
	
	
	public static void main(String args[])
	{
	new demo3();

	}



}












