import javax.swing.*;

class demo1
{
	public static void main(String args[])
	{
		JFrame f1=new JFrame("Frame1");
		f1.setTitle("My Frame");
		f1.setVisible(true);
		f1.setSize(100,100);
		f1.setLocation(100,500);
	}
	

}













