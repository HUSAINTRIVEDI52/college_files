awk 'BEGIN {
		i = 10
		while(i>5)
		{
		 printf "%d \n", i
		 i--
		} 
	    }'


