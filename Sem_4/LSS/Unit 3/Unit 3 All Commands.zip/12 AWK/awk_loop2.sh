awk 'BEGIN {
	for(i=1;i<=10;i++)
        print "cube of", i, "is", i*i*i;
	print "=======================";

	 }'
