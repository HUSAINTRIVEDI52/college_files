# By default prints the first 10 lines from a  file
head  data.txt
tail data.txt
echo "prints the first n lines from a file"
head -n 3 data.txt

echo "Print Middle lines (5,6)"
head -6 data.txt | tail -2

