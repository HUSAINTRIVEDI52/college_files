# translate with file
tr '|/' '~-' < file.txt
