echo "Sort File"
sort file1
echo "________"
sort file3
echo "________one first col consider"
echo "Sort File in Reverse Order"
sort -r file1
echo "______"
echo "Sort File Numerically"
sort -n file3
echo "______"
echo "Sort file Uniquely (Remove Redudancy)"
sort -u file1
echo "______"
echo "Sort Month Wise"
sort -M month
echo "_______"
echo "Sort According to 2nd Column"
sort -k2 file4







