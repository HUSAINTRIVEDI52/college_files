#Limit column width
fold -w 10 foldfile.txt
echo "\n"

#Wrap on spaces
fold -w 20 -s foldfile.txt
echo "\n"
