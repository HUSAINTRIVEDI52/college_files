# By default diplay  last 10 ines from the file
tail head.txt
# Display last N lines
tail -n 5 head.txt

