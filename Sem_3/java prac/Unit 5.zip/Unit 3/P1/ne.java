// Write a Program based on package. Create package P1 and P2 to perform following 
// task.
// P1 package will accept the customer accno and name.
// P2 pacakge will have following methods.
// Deposite amount
// Withdraw amount
// Check Balance
 


package P1;

public class ne{
    private int accno;
    private  String name;

    public ne(int accno,String name)
    {

        this.accno=accno;
        this.name=name;
    }
    int acno()
    {
        return accno;
    }
    String getname()
    {
        return name;
    }
}
