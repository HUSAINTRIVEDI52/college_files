 catch (Exception e) // to handle any type of Exception
		// {
		// 	System.out.println(e);
		// }