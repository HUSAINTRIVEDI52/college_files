public class Exc14
	    {  
		public static void main(String args[])
			{  
				try
				{
					System.out.println("sdfs");
					
				}
				catch(Exception e)
				{
					System.out.println("exception handled");
				}
      
				finally
				{
						System.out.println("Sdfsfd");
				}
				System.out.println("normal flow...");  
      }  
      
    }  