class Array2{
	//return the array from  function
	
	static int[] create()//array
	{
		int[] ar={10,20,30};
		return ar;//array
	}
	
		
	public static void main(String[] args)
	{
		
				
		int[] newarr=create();//array
		
		for(int i=0;i<newarr.length;i++)
		{
				System.out.println(newarr[i]);
		}

		
		
		
		
		
	}
	
}