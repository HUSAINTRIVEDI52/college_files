class CommandLine{

	//command line arguments....run time..interprete java
	public static void main(String[] args)
	{
		String no1=args[0];
		String no2=args[1];
		
		int a=(int)no1;
		int b=(int)no2;
		System.out.println("Entered name is : "+args[0]);
		System.out.println("Entered name is : "+args[1]);
		System.out.println("Entered name is : "+args[2]);
		int ans=a+b;
		System.out.println("Entered name is : "+ans);
		
		
		
		
		
		
		
		
	}
	
}


			
			
			


