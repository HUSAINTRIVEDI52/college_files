class Varargs{
		//variable arguments: pass n arguements
		//int ... a: array
	static void java(String k,int ... a)
	{
				System.out.println(k);

		System.out.println("Len:"+a.length);
		for(int i:a){
		//System.out.println(a[0]);
			sum +=a[]
		}
		
	}
	public static void main(String[] args) 
	{
		java("hi",10);
		java("Hello",10,20);
		
		
		
		
		
		
		
		
		
		java("bye",10,20,30,40,50);
		java();
	}  
}  