class Student_info1{
		int rno;
		String name,college;
		
	Student_info1()
	{
		System.out.println("Default cons");
	}
	Student_info1(int rno,String name)
	{
		Scanner
		
		
		this();//
		this.rno=rno;
		this.name=name;
	
	}
	

	public static void main(String[] args)
	{
			
		Student_info1 s2=new Student_info1(101,"GLS");

		
			
		
		
		
		
	}		

	
}