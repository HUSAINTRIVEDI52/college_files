import java.lang.*;
class StringBuffers{
	public static void main(String[] args)
	{
		StringBuffer sb=new StringBuffer();
		//append
		sb.append("core");
		//capacity-return int default 16
		System.out.println(sb.capacity());
		
		
	}
	
}