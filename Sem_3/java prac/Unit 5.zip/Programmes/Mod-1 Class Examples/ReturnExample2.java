public class ReturnExample2 {  
    void display()  
    {  
        return null;  
    }  
    public static void main(String[] args) {  
    ReturnExample2 e =new ReturnExample2();  
    e.display();  
}  
    }  