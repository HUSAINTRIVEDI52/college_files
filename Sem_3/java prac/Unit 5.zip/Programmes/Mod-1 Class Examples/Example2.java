class Example2{

		
	public static void main(String[] args)//command line
	{
		
		//variable: vary+able...... hold the values
		//...type of data we need the variable
		
		int a=10,b=20;
		System.out.println("A ="+a+"B ="+b+" + ="+(a+b));
		
		
		
		
		
		
	}
}

