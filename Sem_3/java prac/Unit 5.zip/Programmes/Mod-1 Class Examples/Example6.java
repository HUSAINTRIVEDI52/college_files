import java.util.Scanner;

class Example6{

	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter any no: ");
		int no=s.nextInt();
		
		System.out.println("Enter your name: ");
		String name=s.next();

		
		System.out.println("Entered no is "+no);
		System.out.println("Your name is "+name);
		
		
	}
	
}