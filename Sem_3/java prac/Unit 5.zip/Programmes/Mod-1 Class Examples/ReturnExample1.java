public class ReturnExample1 {  
  
     int display()  
    {  
        return 10;  
    }  
    public static void main(String[] args) {  
    ReturnExample1 e =new ReturnExample1();  
    System.out.println(e.display());  
}  
  
}  