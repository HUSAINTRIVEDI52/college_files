class Example10{

	public static void main(String[] args)
	{
		//int a=10;
		
		//double d=a;
		
		double d=145.55;
		
		//int a=(int)d;
		
		
		char a='g';
		
		int asc=(int)a;
		
		
		
		
		
		
		System.out.println(asc);
		
	}
	
}