class Example5{

	public static void main(String[] args)
	{
		//narrow type casting
		double d=145.14;
		
		long l=(long)d;
		
		int k=(int)l;
		
		
		System.out.println(k);
		
		
	}
	
}