class Example4{

	public static void main(String[] args)
	{
		//widering type casting
		int a=10;
		
		long b=a;
		
		float f=b;
		
		System.out.println("int a: "+ a);
		System.out.println("long b: "+ b);
		System.out.println("float f: "+ f);
		
		
	}
	
}