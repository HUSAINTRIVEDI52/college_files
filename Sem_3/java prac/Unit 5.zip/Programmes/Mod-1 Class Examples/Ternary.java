public class Ternary
{    
  public static void main(String[] args)
 {    
    int number=13;    
      
    String output=(number%2==0)?"even number":"odd number";    
    System.out.println(output);  
  }    
}    