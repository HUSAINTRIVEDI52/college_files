class Example1{
	public static void main(String[] args)//command line
	{
		int a=10;
		int b=20;
		int z=a+b;
		System.out.println(z);		
	}
}
