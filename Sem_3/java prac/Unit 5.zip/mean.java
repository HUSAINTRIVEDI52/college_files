// . Define a class called StatisticalData which manage a number of readings of type 
// int. Provide a method to setData avaialble in the form of an array, a method add to 
// individually and data of type int, a method to reset the entire data, and methods to 
// return the following statistics:
// Mean 
// Median
// Mode

public class mean {
    
}
