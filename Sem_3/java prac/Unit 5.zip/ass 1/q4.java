// Write a Java program that will convert a float datatype into an int data type. Perform
// Type conversion.

public class q4 {
    public static void main(String[] args)
    {

        float conversion=90.0f;
        int  converted=(int)conversion;
        System.out.println("The float data type is "+conversion);
        System.out.println("The int data type is "+converted);
    }
}
