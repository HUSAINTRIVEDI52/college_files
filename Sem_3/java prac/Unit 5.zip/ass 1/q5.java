// rite a Java program that will convert an integer data type into a double data type.
// Perform Type Conversion.
public class  q5 {
         public static void main(String[] args)
         {
                   int conversion=30;
                   double converted=conversion;
                   System.out.println("The following data type is integer datatype"+conversion);
                   System.out.println("The following datatype is double datatype"+converted);
         }    
}
