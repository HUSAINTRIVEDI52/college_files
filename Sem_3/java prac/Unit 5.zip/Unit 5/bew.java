import java.applet.Applet;
import java.awt.Graphics;

public class bew extends Applet {
    public void paint(Graphics g) {
        g.drawLine(10, 10, 50, 50);
    }
}
//<applet code=applet.class height=20 width=20 >