import java.util.*;
public class sum
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int sum=0;
        int input;
        System.out.println("Enter the  n value to get the sum ");
        input=sc.nextInt();
        for(int i=1;i<=input;i++)
        {
            sum=sum+i;
        }
        System.out.println("The sum of n numbers is"+sum);
    }

}